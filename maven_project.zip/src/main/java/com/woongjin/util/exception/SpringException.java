package com.woongjin.util.exception;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
public class SpringException {
	
	private final Logger logger = LoggerFactory.getLogger(getClass());
	
    @ExceptionHandler(Exception.class)
    public ModelAndView allException(Exception e) {
    	ModelAndView modelAndView = new ModelAndView("error/allException");
    	modelAndView.addObject("error", e.getClass().getSimpleName());
    	modelAndView.addObject("message",e.getMessage());
    	
    	logger.error(e.toString(),e);
    	
    	return modelAndView;
    }
    
    @ExceptionHandler(GenericException.class)
    public ModelAndView genericException(GenericException e) {
    	ModelAndView modelAndView = new ModelAndView("error/genericException");
    	modelAndView.addObject("error", e.getClass().getSimpleName());
    	modelAndView.addObject("message", e.getExceptionCode()+" - "+e.getExceptionMsg());
    	logger.error(e.getExceptionCode()+" - "+e.getExceptionMsg(),e);
    	return modelAndView;
    }
    
    @ExceptionHandler(AjaxException.class)
    public @ResponseBody Map<String,Object> ajaxException(AjaxException e) {
    	
    	Map<String,Object> resultMap = new HashMap<String,Object>();
    	resultMap.put("error", e.getClass().getSimpleName());
    	resultMap.put("message", e.getExceptionCode()+" - "+e.getExceptionMsg());
    	logger.error(e.getExceptionCode()+" - "+e.getExceptionMsg(),e);
    	return resultMap;
    }
}
