package com.woongjin.user.service.impl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.woongjin.user.dao.UserInfoDao;
import com.woongjin.user.search.UserInfoSearch;
import com.woongjin.user.service.UserInfoService;
import com.woongjin.user.vo.UserInfoVo;
import com.woongjin.util.EncryptUti;

@Service
public class UserInfoServiceImpl implements UserInfoService {
   @Autowired
   private UserInfoDao userInfoDao;
   
   @Override
   public List<UserInfoVo> selectList(UserInfoSearch search){
	   return userInfoDao.selectList(search);
   }


@Override
public UserInfoVo select(String userId) {
	// TODO Auto-generated method stub
	return userInfoDao.select(userId);
}

@Override
public void insert(UserInfoVo vo) {
	// TODO Auto-generated method stub
	userInfoDao.insert(vo);
	
}

@Override
public void update(UserInfoVo vo) throws Exception {
	// TODO Auto-generated method stub
	vo.setPassword(EncryptUti.getEncMD5(vo.getPassword()));
	userInfoDao.update(vo);
}

@Override
public void delete(String userId) {
	// TODO Auto-generated method stub
	userInfoDao.delete(userId);
}


@Override
public int selectListCount(UserInfoSearch search) {
	return userInfoDao.selectListCount(search);
}

   
}
