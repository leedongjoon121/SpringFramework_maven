package com.woongjin.board.validator;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.woongjin.board.vo.GuestBookVo;

@Component
public class GuestBookValidator implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return GuestBookVo.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		GuestBookVo vo = (GuestBookVo) target;
		if(StringUtils.isEmpty(vo.getTITLE())) { //  StringUtils : null 값하고 공백을 체크 해줌 
			errors.reject("error_title","title is empty!!");
		}
	}

}
