package com.woongjin.board.vo;

import java.io.Serializable;

public class GuestBookVo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	private String GUEST_BOOK_ID;
	private String TITLE;
	private String CONTENT;
	private String PASSWORD;
	private String REGISTER_NAME;
	
	public String getGUEST_BOOK_ID() {
		return GUEST_BOOK_ID;
	}
	public void setGUEST_BOOK_ID(String gUEST_BOOK_ID) {
		GUEST_BOOK_ID = gUEST_BOOK_ID;
	}
	public String getTITLE() {
		return TITLE;
	}
	public void setTITLE(String tITLE) {
		TITLE = tITLE;
	}
	public String getCONTENT() {
		return CONTENT;
	}
	public void setCONTENT(String cONTENT) {
		CONTENT = cONTENT;
	}
	public String getPASSWORD() {
		return PASSWORD;
	}
	public void setPASSWORD(String pASSWORD) {
		PASSWORD = pASSWORD;
	}
	public String getREGISTER_NAME() {
		return REGISTER_NAME;
	}
	public void setREGISTER_NAME(String rEGISTER_NAME) {
		REGISTER_NAME = rEGISTER_NAME;
	}
	public String getREGIST_DATE() {
		return REGIST_DATE;
	}
	public void setREGIST_DATE(String rEGIST_DATE) {
		REGIST_DATE = rEGIST_DATE;
	}
	public String getUPDATER_NAME() {
		return UPDATER_NAME;
	}
	public void setUPDATER_NAME(String uPDATER_NAME) {
		UPDATER_NAME = uPDATER_NAME;
	}
	public String getUPDATE_DATE() {
		return UPDATE_DATE;
	}
	public void setUPDATE_DATE(String uPDATE_DATE) {
		UPDATE_DATE = uPDATE_DATE;
	}
	private String REGIST_DATE;
	private String UPDATER_NAME;
	private String UPDATE_DATE;
	
	
   
	

}
