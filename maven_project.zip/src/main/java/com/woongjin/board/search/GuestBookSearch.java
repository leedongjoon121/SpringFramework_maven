package com.woongjin.board.search;

import com.woongjin.util.Search;

public class GuestBookSearch extends Search{

}
