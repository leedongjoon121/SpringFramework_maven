package com.woongjin.board.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.woongjin.board.search.GuestBookSearch;
import com.woongjin.board.service.GuestBookService;
import com.woongjin.board.validator.GuestBookValidator;
import com.woongjin.board.vo.GuestBookVo;



@Controller
public class GuestBookController {
	   @Autowired
	   private GuestBookService guestbookService;

	   @Autowired
	   private GuestBookValidator guestbookvalidator;
	   
	   @RequestMapping(value="/guest/list.do")
	   public ModelAndView list(GuestBookSearch search) {
		   
		   search.calculate(guestbookService.selectListCount(search));
		   ModelAndView view = new ModelAndView("board/guestBook/list");
		   view.addObject("list",guestbookService.selectList(search));
		   view.addObject("search", search);
	      return view;
	   }
	   
	   
	   @RequestMapping(value="/guest/insertForm.do")
	   public ModelAndView insertForm() {
		   
		   ModelAndView view = new ModelAndView("board/guestBook/insertForm");   
	      return view;
	   }
	   
	   @RequestMapping(value="/guest/insert.do") 
	   public ModelAndView insert(GuestBookVo vo, BindingResult bindingResult) {
		   
		   guestbookvalidator.validate(vo, bindingResult); // 유효성 검사한 결과 값을 담아 준다.
		   
		   ModelAndView view = new ModelAndView("redirect:/guest/view.do");
		   
		   if(bindingResult.hasErrors()) {// 에러가 있는 경우 
			   List<ObjectError> errors = bindingResult.getAllErrors(); // 모든 에러 담고
			   for(ObjectError error : errors) {
				   
				   view.addObject(error.getCode(),error.getDefaultMessage()); // 뷰에 담음 
			   }
			   view.addObject("message", "에러!!");
			   view.setViewName("board/guestBook/insertForm");
		   }else {
			   guestbookService.insert(vo);
			   view.addObject("GUEST_BOOK_ID", vo.getGUEST_BOOK_ID());
			   view.addObject("message", "성공!");
		   } 
	      return view;
	   }
	   
	   
	   // view는 각 list의 상세 값들 나타내는 것들 임
	   @RequestMapping(value="/guest/view.do")  
	   public ModelAndView view(
			   @RequestParam(value="GUEST_BOOK_ID", required=true) String GUEST_BOOK_ID
			   ) {
		   
		   ModelAndView view = new ModelAndView("board/guestBook/view");
		   view.addObject("obj",guestbookService.select(GUEST_BOOK_ID));
		   	   
	      return view;
	   }
	   
	  
	   @RequestMapping(value="/guest/updateForm.do")
	   public ModelAndView updateForm(
			   @RequestParam(value="GUEST_BOOK_ID", required=true) String GUEST_BOOK_ID
			   ) {
		   
		   ModelAndView view = new ModelAndView("/board/guestBook/updateForm");
		   view.addObject("obj",guestbookService.select(GUEST_BOOK_ID));
		   
	      return view;
	   }
	  

	   @RequestMapping(value="/guest/update.do")
	   public ModelAndView update(GuestBookVo vo) {

		   guestbookService.update(vo);
	
		   ModelAndView view = new ModelAndView("redirect:/guest/view.do");
		   view.addObject("GUEST_BOOK_ID",vo.getGUEST_BOOK_ID());
	      return view;
	   }
	   
	   
	   
	   @RequestMapping(value="/guest/delete.do")
	   public ModelAndView delete(
			   @RequestParam(value="GUEST_BOOK_ID", required=true) String GUEST_BOOK_ID
			   ) {
		   guestbookService.delete(GUEST_BOOK_ID);
		   
		   ModelAndView view = new ModelAndView("redirect:/guest/list.do");
		   
	      return view;
	   }
	     
	   
}
