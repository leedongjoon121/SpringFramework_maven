package com.woongjin.board.dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.woongjin.board.dao.GuestBookDao;
import com.woongjin.board.search.GuestBookSearch;
import com.woongjin.board.vo.GuestBookVo;

@Repository
public class GuestBookDaoImpl implements GuestBookDao{
		   
	@Autowired
	@Resource(name="sqlSessionTemplate")
	private SqlSession query;
	
	private final static String MAPPER = "board.guestbookDao.";
	
	@Override
	public List<GuestBookVo> selectList(GuestBookSearch search) {
		// TODO Auto-generated method stub
		return query.selectList(MAPPER+"selectList", search);
	}

	@Override
	public int selectListCount(GuestBookSearch search) {
		// TODO Auto-generated method stub
		return query.selectOne(MAPPER+"selectListCount",search);
	}

	@Override
	public GuestBookVo select(String param1) {
		// TODO Auto-generated method stub
		 return query.selectOne(MAPPER+"select",param1);
	}

	@Override
	public void insert(GuestBookVo vo) {
		// TODO Auto-generated method stub
		 query.insert(MAPPER+"insert",vo);
	}

	@Override
	public void update(GuestBookVo vo) {
		// TODO Auto-generated method stub
		query.update(MAPPER+"update",vo);
	}

	@Override
	public void delete(String param1) {
		// TODO Auto-generated method stub
		query.delete(MAPPER+"delete",param1);
	}

}
