package com.woongjin.board.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.woongjin.board.dao.GuestBookDao;
import com.woongjin.board.search.GuestBookSearch;
import com.woongjin.board.service.GuestBookService;
import com.woongjin.board.vo.GuestBookVo;
import com.woongjin.support.service.SeqInfoService;


@Service
public class GuestBookServiceImpl implements GuestBookService{
	  
	@Autowired
	private GuestBookDao guestDao;
	
	@Autowired
	SeqInfoService seqinfoservice;
	   
	@Override
	public List<GuestBookVo> selectList(GuestBookSearch search) {
		// TODO Auto-generated method stub
		   return guestDao.selectList(search);
	}

	@Override
	public int selectListCount(GuestBookSearch search) {
		// TODO Auto-generated method stub
		return guestDao.selectListCount(search);
	}

	@Override
	public GuestBookVo select(String param1) {
		// TODO Auto-generated method stub
		return guestDao.select(param1);
	}

	@Override
	public void insert(GuestBookVo vo) {
		// TODO Auto-generated method stub
		vo.setGUEST_BOOK_ID(seqinfoservice.getGuestBookNextId());
		guestDao.insert(vo);
	}

	@Override
	public void update(GuestBookVo vo) {
		// TODO Auto-generated method stub
		guestDao.update(vo);
	}

	@Override
	public void delete(String param1) {
		// TODO Auto-generated method stub
		guestDao.delete(param1);
	}

}
