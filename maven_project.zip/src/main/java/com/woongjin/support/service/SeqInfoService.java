package com.woongjin.support.service;

public interface SeqInfoService {
	 public String getGuestBookNextId();
}
