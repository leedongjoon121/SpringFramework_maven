package com.woongjin.support.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.WritableByteChannel;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.woongjin.support.dao.FileInfoDao;
import com.woongjin.support.service.FileInfoService;
import com.woongjin.support.vo.FileInfoVo;
import com.woongjin.util.BaseService;
import com.woongjin.util.HttpUtil;
import com.woongjin.util.exception.GenericException;

@Service
public class FileInfoServiceImpl extends BaseService implements FileInfoService{

	@Value("${file.root.path}")
	private String rootPath;
	
	 @Autowired
	 private FileInfoDao fileInfoDao;
	
	@Override
	public List<FileInfoVo> selectList() {
		// TODO Auto-generated method stub
		return fileInfoDao.selectList();
	}

	@Override
	public int selectListCount() {
		// TODO Auto-generated method stub
		return  fileInfoDao.selectListCount();
	}

	@Override
	public FileInfoVo select(String fileId) {
		// TODO Auto-generated method stub
		return fileInfoDao.select(fileId);
	}

	@Override
	public List<FileInfoVo> insert(List<MultipartFile> multipartFiles) { // 여러개 파일 읽으려고 그냥 만들어 놓은 것
		// TODO Auto-generated method stub
		List<FileInfoVo> voList = new ArrayList<FileInfoVo>(); // 파일 정보를 읽어서 호출 가능하게 루트? 잡아줌
		
		for(MultipartFile multipartFile : multipartFiles) {
			voList.add(insert(multipartFile)); // 여기서 실제 로직이 수행됨
		}
		
		return voList;
	}

	@Override
	public FileInfoVo insert(MultipartFile multipartFile) { // 실제 로직 수행 부분 
		// 멀티 파트는 폼에서 데이터 쏘면 스트림형식으로 서버가 받음 그걸 멀티파트가 받을 수 잇음
		// 원하는 정보를 뽑아서 원하는 위치에 저장함 
		
		String originalFileName = multipartFile.getOriginalFilename(); // 원래 파일명
		String contentType = multipartFile.getContentType();  // 파일 형식
		long fileSize = multipartFile.getSize(); // 파일 사이즈
		String fileId = UUID.randomUUID().toString().replace("-", ""); // 파일 아이디, 랜덤으로 만든다
		String dirPath = DateFormatUtils.format(new Date(), "yyyy/MM/dd");
		String fullPath = rootPath+dirPath;
		
		File dir = new File(fullPath); // 파일에다가 디렉터리 경로 넣은거 대입시켜서
		if(!dir.isDirectory())dir.mkdirs();  // 실제 있는지 확인 해서 없으면 디렉터리 만듬, mkdirs : 하면 전체 경로를 다 만들어줌 
		
		String path = fullPath + fileId;  // 파일 이름을 만듬 
		File f = new File(path); // 공간을 잡아줌 
		try {
			multipartFile.transferTo(f); // 멀티파티에서 복사를 해줌  : 내가 원하는 경로에 디렉터리가 복사됨 
		}catch(Exception e) {
               throw new GenericException("file", e.toString());			
		}
		
		//실제 디비에 인서트 하는 부분
		FileInfoVo vo = new FileInfoVo();
		vo.setFileId(fileId);
		vo.setOrgFileName(originalFileName);
        vo.setContentType(contentType);	
        vo.setFileSize(fileSize);
        vo.setFilePath(dirPath);
        vo.setRegisterId((String) getRequestAttribute("userId"));
        fileInfoDao.insert(vo);

        return vo;
	}

	@Override
	public void delete(String fileId) {
		// TODO Auto-generated method stub
		FileInfoVo vo = fileInfoDao.select(fileId);
		String fullPath = rootPath +vo.getFilePath()+vo.getFileId();
		File file = new File(fullPath);
		if(!file.exists()) {
			throw new GenericException("file", "파일이 없습니다");
			
		}
		
		if(file.delete()) { // 실제 파일을 지우고  성공하면
			fileInfoDao.delete(fileId);  // 디비에서도 지운다 .
		}else {
			throw new GenericException("file", "파일 삭제에 실패 하였습니다.");
		}
		
	}

	// 파일 클릭하면 다운로드 됨 
	@Override
	public void downloadFile(HttpServletRequest request, HttpServletResponse response, String fileId) { // 파일 아이디 넣어서 다운로드 시킴
		// TODO Auto-generated method stub
		FileInfoVo vo = fileInfoDao.select(fileId); // 디비에서 가져와서 정보 가져오고 : 
		String downloadFileName = vo.getOrgFileName(); // 원본 파일 명 
		String fullPath = rootPath + vo.getFilePath() + vo.getFileId();
		File downloadFile = new File(fullPath); // 다시 파일에 경로 올림
		try {
			FileInputStream fin = new FileInputStream(downloadFile);
			downloadFile(request,response,downloadFileName,fin); // 실제 다운로드 하는 부분호출
			
		}catch(FileNotFoundException e) {
			throw new GenericException("file", e.toString());
		}
		
	}

	// 실제 다운로드 하는 부분  마지막 파라미터에 스트림형식으로 파일을 전송 받아 
	@Override
	public void downloadFile(HttpServletRequest request, HttpServletResponse response, String downloadFileName, FileInputStream fin) {
		// TODO Auto-generated method stub
		FileChannel source = null;
		WritableByteChannel destination = null;
		
		try {
			
			downloadFileName = HttpUtil.getDisposition(downloadFileName, HttpUtil.getBrowser(request));
			
			source = fin.getChannel(); // 파일을 주고 받을수 있게 통로 역할을 해줌 
			destination = Channels.newChannel(response.getOutputStream()); // 목적지를 선언 해서 내려준다 .
			
			if(StringUtils.isEmpty(response.getContentType()) || response.getContentType().indexOf("/") == -1) {
				response.setContentType("application/x-msdownload");
			}
			
			response.setHeader("Content-Disposition", "attachment;filename="+downloadFileName+";");
			source.transferTo(0, fin.available(),destination); // 실제 밀어서 넣어 주는 역할 
		}catch(Exception e) {
			throw new GenericException("file", e.toString());
		}finally {
			try {
				if(fin != null) {
					fin.close();
				}
				if(source != null) {
					source.close();
				}
				if(destination != null){
					destination.close();
				}
			}catch(Exception e) {
				throw new GenericException("file", e.toString());
			}
		}
	}

}
