package com.woongjin.support.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.woongjin.support.dao.SeqInfoDao;
import com.woongjin.support.service.SeqInfoService;

@Service
public class SeqInfoServiceImpl implements SeqInfoService {

	 @Autowired
	 private SeqInfoDao seqInfoDao;
	 
	@Override
	public String getGuestBookNextId() { // 파라미터
		// TODO Auto-generated method stub
		
		/*
		 * % : 명령 시작을 의미
		 * 0 : 채워질 문자
		 * 20 : 총 자리 수
		 * d : 십진수로 된 정수
		 * */
		
		return String.format("%020d", seqInfoDao.getGuestBookNextId());
	}

}
