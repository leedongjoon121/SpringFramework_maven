package com.woongjin.support.dao;

import java.util.List;

import com.woongjin.support.vo.FileInfoVo;

public interface FileInfoDao {
	  public List<FileInfoVo> selectList(); 
	   
	   public int selectListCount();
	   /*
	    * 상세
	    * 
	    * */
	   public FileInfoVo select(String fileId);
	   
	   public void insert(FileInfoVo vo);
	   
	   
	   
	   public void delete(String fileId);
}
