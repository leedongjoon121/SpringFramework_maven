package com.woongjin.support.dao.impl;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.woongjin.support.dao.SeqInfoDao;

@Repository
public class SeqInfoDaoImpl implements SeqInfoDao{

	@Resource(name="sqlSessionTemplate")
	private SqlSession query;
	
	private final static String MAPPER = "support.seqInfoDao.";
	
	@Override
	public long getGuestBookNextId() {
		// TODO Auto-generated method stub
		return query.selectOne(MAPPER+"getGuestBookNextId");
	}

}
