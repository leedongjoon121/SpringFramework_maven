package com.woongjin.support.vo;

import java.io.Serializable;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

public class FileInfoVo implements Serializable {
   /**
	 * 
	 */
	private static final long serialVersionUID = -5493323442327117466L;
	
   private String fileId;
   private String orgFileName;
   private  String contentType;
   private long fileSize;
   private String filePath;
   private String registDate;
   
   private List<MultipartFile> multipartFiles;
   
   public String getFileId() {
	return fileId;
}
public List<MultipartFile> getMultipartFiles() {
	return multipartFiles;
}
public void setMultipartFiles(List<MultipartFile> multipartFiles) {
	this.multipartFiles = multipartFiles;
}
public void setFileId(String fileId) {
	this.fileId = fileId;
}
public String getOrgFileName() {
	return orgFileName;
}
public void setOrgFileName(String orgFileName) {
	this.orgFileName = orgFileName;
}
public String getContentType() {
	return contentType;
}
public void setContentType(String contentType) {
	this.contentType = contentType;
}
public long getFileSize() {
	return fileSize;
}
public void setFileSize(long fileSize) {
	this.fileSize = fileSize;
}
public String getFilePath() {
	return filePath;
}
public void setFilePath(String filePath) {
	this.filePath = filePath;
}
public String getRegistDate() {
	return registDate;
}
public void setRegistDate(String registDate) {
	this.registDate = registDate;
}
public String getRegisterId() {
	return registerId;
}
public void setRegisterId(String registerId) {
	this.registerId = registerId;
}
private String registerId;
   
   
}
